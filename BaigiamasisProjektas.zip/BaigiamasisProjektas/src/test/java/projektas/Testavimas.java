package projektas;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.ArrayList;
import java.util.NoSuchElementException;

import java.util.List;
import java.util.Objects;

public class Testavimas {
    private WebDriver driveris;
    private WebDriverWait wait;

    static String slapyvardis = "domantukasx123x";
    static String passwordas = "medelis9X";

    private CookiesAgreement cookiesAgreement;

    @BeforeTest
    public void setUp() {
        driveris = new ChromeDriver();
        driveris.get("https://elenta.lt/");
        driveris.manage().window().maximize();
        wait  = new WebDriverWait(driveris, Duration.ofSeconds(4));
    }

    @AfterTest
    public void tearDown() {
        driveris.quit();
    }

    @Test
    public void cookiesAgreementTest() {
        cookiuAcceptinimas();
    }

    @Test
    public void tuscioLaukelioIeskojimas() {

        WebElement searchMygtukas = driveris.findElement(By.xpath("//*[@value='Ieškoti']"));
        searchMygtukas.click();

        try {
            wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("#list-settings")));
        } catch (TimeoutException e) {
            System.out.println("Į paieškos laukelį nieko nebuvo įvesta.");
        }
    }

    @Test
    public void ivedimasIpaieskosLaukeli() {


        List<String> paieskosVariantai = new ArrayList<>();
        paieskosVariantai.add("Automobilis");
        paieskosVariantai.add("Parduotuvė");
        paieskosVariantai.add("Šaltibarščiai");
        paieskosVariantai.add("Mergina");
        paieskosVariantai.add("Pervežimas");

        for(String paieskosVariantas : paieskosVariantai) {
            String dabartinisUrl = driveris.getCurrentUrl();

            WebElement paieskosLaukelis = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("search-page-box")));
            paieskosLaukelis.clear();
            paieskosLaukelis.sendKeys(paieskosVariantas);

            WebElement searchMygtukas = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@value='Ieškoti']")));
            searchMygtukas.click();

            String naujasUrl = driveris.getCurrentUrl();
            Assert.assertNotEquals(naujasUrl, dabartinisUrl, "Mygtukas nepasispaudė");
        }

        System.out.println("Visi paieškos žodžiai buvo įvesti.");
    }

    @Test
    public void registracija() {

        WebElement prisijungimoBtn = driveris.findElement(By.xpath("//*[@id='header-container-nav']/a[3]"));
        wait.until(ExpectedConditions.visibilityOf(prisijungimoBtn));
        prisijungimoBtn.click();

        Assert.assertEquals(driveris.getCurrentUrl(), "https://elenta.lt/prisijungti?returnurl=https%3A%2F%2Felenta.lt%2F", "Mygtukas nepasispaudė");

        WebElement registracijosBtn = driveris.findElement(By.xpath("//*[@id='form']/fieldset/table/tbody/tr[10]/td/p/a"));
        registracijosBtn.click();

        Assert.assertEquals(driveris.getCurrentUrl(), "https://elenta.lt/registracija", "Registracijos mygtukas nepasispaudė");

        WebElement inputNick = driveris.findElement(By.id("UserName"));
        inputNick.sendKeys(slapyvardis);

        WebElement email = driveris.findElement(By.id("Email"));
        email.sendKeys("wiyayeg639@bsidesmn.com");

        WebElement slaptazodis = driveris.findElement(By.id("Password"));
        slaptazodis.sendKeys(passwordas);

        WebElement pakSlaptazodi = driveris.findElement(By.id("Password2"));
        pakSlaptazodi.sendKeys(passwordas);

        WebElement regBtn = driveris.findElement(By.xpath("//*[@value='Registruotis']"));
        regBtn.click();

        try {
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='main-container']/div[2]/h1/b")));
        } catch (TimeoutException e) {
            Assert.fail("Nepavyko užregistruoti paskyros (greičiausiai jau tokia egzistuoja).");
        }

        System.out.println("Paskyra užregistruota.");

    }

    @Test
    public void prisijungimas() {

        WebElement prisijungimoBtn = driveris.findElement(By.xpath("//*[@id='header-container-nav']/a[3]"));
        wait.until(ExpectedConditions.visibilityOf(prisijungimoBtn));
        prisijungimoBtn.click();

        Assert.assertEquals(driveris.getCurrentUrl(), "https://elenta.lt/prisijungti?returnurl=https%3A%2F%2Felenta.lt%2F", "Mygtukas nepasispaudė");

        WebElement nickname = driveris.findElement(By.id("UserName"));
        nickname.sendKeys(slapyvardis);

        WebElement slaptazodis = driveris.findElement(By.id("Password"));
        slaptazodis.sendKeys(passwordas);

        WebElement mygtukasLogin = driveris.findElement(By.xpath("//*[@value='Prisijungti']"));
        mygtukasLogin.click();

        try {
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='my-ads-nav-button']")));
        } catch (TimeoutException e) {
            Assert.fail("Nepavyko prisijungti prie paskyros.");
        }

        System.out.println("Sėkmingai prisijungta prie paskyros.");

        //Atsijungiam, kad testas galėtų toliau suktis kai prieis prie registracijos, nes kitaip nematys button'o.
        WebElement atsijungti = driveris.findElement(By.xpath("//*[@id='my-ads-nav-button']"));
        atsijungti.click();
        WebElement atsijungtiBtn = driveris.findElement(By.xpath("//*[@id='main-container']/table/tbody/tr[1]/td[3]/a[2]"));
        atsijungtiBtn.click();

    }


    private void cookiuAcceptinimas() {
        cookiesAgreement = new CookiesAgreement(driveris);
        cookiesAgreement.nuspaustiMygtuka();
    }
}
