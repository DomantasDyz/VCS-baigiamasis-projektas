package projektas;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CookiesAgreement {
    private WebDriver driver;

    private By cookiesAcceptMygtukas = By.xpath("//*[@class='fc-footer-buttons-container']//*[@class='fc-button fc-cta-consent fc-primary-button']");

    public CookiesAgreement(WebDriver driver) {
        this.driver = driver;
    }


    public void nuspaustiMygtuka() {
        driver.findElement(cookiesAcceptMygtukas).click();
    }
}
